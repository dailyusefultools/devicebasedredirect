<?php
/**
 * Plugin Name: DeviceRedirect24
 * Plugin URI: https://dailyuseful.tools/deviceredirect24/
 * Description: Create smart links that automatically redirect users to different URLs based on their device (iOS, Android, Desktop). Perfect for app marketing and multi-platform campaigns.
 * Version: 2.2.0
 * Author: deviceredirect24
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: deviceredirect24
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Tested up to: 6.9
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('DBRD_VERSION', '2.2.0');
define('DBRD_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('DBRD_PLUGIN_URL', plugin_dir_url(__FILE__));
define('DBRD_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Free tier limits
define('DBRD_FREE_LINKS_LIMIT', 3);
define('DBRD_FREE_CLICKS_LIMIT', 1000);

/**
 * Main Plugin Class
 */
class DBRD_Main {
    
    private static $instance = null;
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    /**
     * Load required files
     */
    private function load_dependencies() {
        // Core classes
        require_once DBRD_PLUGIN_DIR . 'includes/class-dbrd-database.php';
        require_once DBRD_PLUGIN_DIR . 'includes/class-dbrd-router.php';
        require_once DBRD_PLUGIN_DIR . 'includes/class-dbrd-analytics.php';
        require_once DBRD_PLUGIN_DIR . 'includes/class-dbrd-license.php';
        
        // Admin classes
        if (is_admin()) {
            require_once DBRD_PLUGIN_DIR . 'admin/class-dbrd-admin.php';
            require_once DBRD_PLUGIN_DIR . 'admin/class-dbrd-links-list.php';
        }
    }
    
    /**
     * Initialize WordPress hooks
     */
    private function init_hooks() {
        // Activation/Deactivation
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Init
        add_action('init', array($this, 'init'));
        add_action('template_redirect', array('DBRD_Router', 'handle_redirect'));
        
        // Admin
        if (is_admin()) {
            DBRD_Admin::get_instance();
        }
    }
    
    /**
     * Plugin initialization
     */
    public function init() {
        // WordPress automatically loads translations from /languages since WP 4.6
        
        // Add rewrite rule for /go/ links
        add_rewrite_rule('^go/([^/]+)/?$', 'index.php?dbrd_link=$matches[1]', 'top');
        add_rewrite_tag('%dbrd_link%', '([^&]+)');
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        DBRD_Database::create_tables();
        
        // Maybe update database schema for existing installations
        $this->maybe_update_database();
        
        // Set flag to flush rewrite rules on next admin load (more reliable)
        add_option('dbrd_flush_rewrite_rules_flag', '1');

        // Also try to flush now
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        flush_rewrite_rules();
    }
    
    /**
     * Maybe update database schema
     */
    private function maybe_update_database() {
        global $wpdb;
        $table = $wpdb->prefix . 'dbr_links';
        
        // Check if desktop_url is NOT NULL (migration from old version)
        $column = $wpdb->get_row("SHOW COLUMNS FROM `{$table}` LIKE 'desktop_url'");
        
        if ($column && $column->Null === 'YES') {
            // Make desktop_url required for existing installations
            $wpdb->query("ALTER TABLE `{$table}` MODIFY `desktop_url` varchar(2048) NOT NULL");
        }
    }
}

/**
 * Initialize the plugin
 */
function dbrd_init() {
    return DBRD_Main::get_instance();
}

// Auto-flush rewrite rules if needed (handles activation issues)
add_action('admin_init', function() {
    if (get_option('dbrd_flush_rewrite_rules_flag')) {
        flush_rewrite_rules();
        delete_option('dbrd_flush_rewrite_rules_flag');
    }
});

// Start the plugin
dbrd_init();
