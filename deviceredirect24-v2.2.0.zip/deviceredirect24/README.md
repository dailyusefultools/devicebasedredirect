# DeviceRedirect24

**WordPress plugin for smart device-based redirects.**

Create short links that automatically detect your visitor's device and redirect them to the right destination.

→ **iOS users** → App Store
→ **Android users** → Play Store
→ **Desktop users** → Your website

## Features

- ✅ Unlimited links
- ✅ Unlimited clicks
- ✅ Device detection (iOS, Android, Desktop)
- ✅ Analytics with charts
- ✅ Smart fallback to Desktop URL
- ✅ Clean URLs: `yoursite.com/go/myapp`
- ✅ 100% Free & Open Source

## Installation

1. Download the latest release
2. Upload to WordPress: Plugins → Add New → Upload Plugin
3. Activate the plugin
4. Go to **DeviceRedirect24 → Add New**

## How It Works

| Device | iOS URL set? | Android URL set? | Result |
|--------|-------------|------------------|--------|
| iPhone | ✅ | - | → iOS URL |
| Android | - | ✅ | → Android URL |
| Desktop | - | - | → Desktop URL (fallback) |

**Desktop URL is always required** – it serves as the universal fallback.

## Example

Create a link `/go/myapp`:
- iOS URL: `https://apps.apple.com/app/myapp`
- Android URL: `https://play.google.com/store/apps/myapp`
- Desktop URL: `https://mywebsite.com`

Share one link, reach all platforms! 🚀

## Privacy

- All data stored locally in your WordPress database
- No external API calls
- No tracking, no analytics services
- GDPR compliant

## Support

- [Documentation](https://dailyuseful.tools/deviceredirect24/docs/)
- [Support](https://dailyuseful.tools/support)

## License

GPL v2 or later
