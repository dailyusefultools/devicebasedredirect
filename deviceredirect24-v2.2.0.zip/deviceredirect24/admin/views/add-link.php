<?php
/**
 * Add/Edit Link Admin Page
 */

if (!defined('ABSPATH')) {
    exit;
}

$user_id = get_current_user_id();
$is_edit = false;
$link = null;

// Handle edit mode with nonce verification
if (isset($_GET['edit']) && isset($_GET['_wpnonce'])) {
    if (wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'dbrd_edit_link')) {
        $link_id = intval($_GET['edit']);
        global $wpdb;
        $table = $wpdb->prefix . 'dbr_links';
        $link = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d AND user_id = %d", $link_id, $user_id));

        if ($link) {
            $is_edit = true;
        } else {
            wp_die(esc_html__('Link not found or you do not have permission to edit it.', 'deviceredirect24'));
        }
    } else {
        wp_die(esc_html__('Security check failed.', 'deviceredirect24'));
    }
}

// Handle errors
$error = isset($_GET['error']) ? sanitize_text_field(wp_unslash($_GET['error'])) : '';
?>

<div class="wrap dbrd-admin-wrap">
    <h1>
        <?php echo $is_edit ? esc_html__('Edit Link', 'deviceredirect24') : esc_html__('Add New Link', 'deviceredirect24'); ?>
    </h1>

    <?php if ($error === 'limit_reached'): ?>
        <div class="notice notice-error">
            <p>
                <?php
                printf(
                    /* translators: %d: link limit number */
                    esc_html__('You have reached the limit of %d links.', 'deviceredirect24'),
                    intval(DBRD_FREE_LINKS_LIMIT)
                );
                ?>
            </p>
        </div>
    <?php elseif ($error === 'desktop_required'): ?>
        <div class="notice notice-error is-dismissible">
            <p><?php esc_html_e('Desktop URL is required. This will be used as fallback for empty device URLs.', 'deviceredirect24'); ?></p>
        </div>
    <?php elseif ($error === 'slug_exists'): ?>
        <div class="notice notice-error is-dismissible">
            <p><?php esc_html_e('This short link is already in use. Please choose a different one.', 'deviceredirect24'); ?></p>
        </div>
    <?php elseif ($error === 'create_failed'): ?>
        <div class="notice notice-error is-dismissible">
            <p><?php esc_html_e('Failed to create link. Please try again.', 'deviceredirect24'); ?></p>
        </div>
    <?php endif; ?>

    <form method="post" class="dbrd-link-form">
        <?php wp_nonce_field('dbrd_link_action', 'dbrd_nonce'); ?>
        <input type="hidden" name="dbrd_action" value="<?php echo $is_edit ? 'update_link' : 'create_link'; ?>">
        <?php if ($is_edit): ?>
            <input type="hidden" name="link_id" value="<?php echo esc_attr($link->id); ?>">
        <?php endif; ?>

        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="link_name"><?php esc_html_e('Link Name', 'deviceredirect24'); ?> *</label>
                </th>
                <td>
                    <input type="text"
                           id="link_name"
                           name="link_name"
                           class="regular-text"
                           value="<?php echo $is_edit ? esc_attr($link->name) : ''; ?>"
                           required>
                    <p class="description">
                        <?php esc_html_e('A descriptive name for your link (e.g., "My App Download")', 'deviceredirect24'); ?>
                    </p>
                </td>
            </tr>

            <tr>
                <th scope="row">
                    <label for="link_slug"><?php esc_html_e('Short Link', 'deviceredirect24'); ?> *</label>
                </th>
                <td>
                    <div class="dbrd-slug-input">
                        <span class="dbrd-slug-prefix"><?php echo esc_html(home_url('/go/')); ?></span>
                        <input type="text"
                               id="link_slug"
                               name="link_slug"
                               class="regular-text"
                               value="<?php echo $is_edit ? esc_attr($link->slug) : ''; ?>"
                               pattern="[a-z0-9-]+"
                               required>
                    </div>
                    <p class="description">
                        <?php esc_html_e('Your custom short link (lowercase letters, numbers, and hyphens only)', 'deviceredirect24'); ?>
                    </p>
                </td>
            </tr>

            <tr>
                <th scope="row">
                    <label for="ios_url"><?php esc_html_e('iOS URL', 'deviceredirect24'); ?></label>
                </th>
                <td>
                    <input type="url"
                           id="ios_url"
                           name="ios_url"
                           class="large-text"
                           value="<?php echo $is_edit ? esc_attr($link->ios_url) : ''; ?>"
                           placeholder="https://apps.apple.com/app/...">
                    <p class="description">
                        <?php esc_html_e('Where to redirect iPhone/iPad users (usually App Store link)', 'deviceredirect24'); ?>
                    </p>
                </td>
            </tr>

            <tr>
                <th scope="row">
                    <label for="android_url"><?php esc_html_e('Android URL', 'deviceredirect24'); ?></label>
                </th>
                <td>
                    <input type="url"
                           id="android_url"
                           name="android_url"
                           class="large-text"
                           value="<?php echo $is_edit ? esc_attr($link->android_url) : ''; ?>"
                           placeholder="https://play.google.com/store/apps/...">
                    <p class="description">
                        <?php esc_html_e('Where to redirect Android users (usually Play Store link)', 'deviceredirect24'); ?>
                    </p>
                </td>
            </tr>

            <tr>
                <th scope="row">
                    <label for="desktop_url"><?php esc_html_e('Desktop URL', 'deviceredirect24'); ?> *</label>
                </th>
                <td>
                    <input type="url"
                           id="desktop_url"
                           name="desktop_url"
                           class="large-text"
                           value="<?php echo $is_edit ? esc_attr($link->desktop_url) : ''; ?>"
                           placeholder="https://yourwebsite.com"
                           required>
                    <p class="description">
                        <?php esc_html_e('Your website URL (used as fallback when device URLs are empty)', 'deviceredirect24'); ?>
                    </p>
                </td>
            </tr>
        </table>

        <p class="submit">
            <button type="submit" class="button button-primary button-large">
                <?php echo $is_edit ? esc_html__('Update Link', 'deviceredirect24') : esc_html__('Create Link', 'deviceredirect24'); ?>
            </button>
            <a href="<?php echo esc_url(admin_url('admin.php?page=dbrd-links')); ?>" class="button button-large">
                <?php esc_html_e('Cancel', 'deviceredirect24'); ?>
            </a>
        </p>
    </form>

    <?php if (!$is_edit): ?>
    <div class="dbrd-info-box">
        <h3><?php esc_html_e('How it works', 'deviceredirect24'); ?></h3>
        <p><?php esc_html_e('Desktop URL is required and serves as the fallback. If you leave iOS or Android URLs empty, users from those devices will be redirected to your Desktop URL instead.', 'deviceredirect24'); ?></p>
        <p><strong><?php esc_html_e('Example:', 'deviceredirect24'); ?></strong> <?php esc_html_e('Set only iOS URL - iPhone users go to App Store, everyone else goes to your website!', 'deviceredirect24'); ?></p>
    </div>
    <?php endif; ?>
</div>
