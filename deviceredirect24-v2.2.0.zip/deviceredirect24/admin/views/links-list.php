<?php
/**
 * All Links Admin Page
 */

if (!defined('ABSPATH')) {
    exit;
}

$user_id = get_current_user_id();
$links = DBRD_Database::get_user_links($user_id);
$usage = DBRD_License::get_usage_stats($user_id);

// Handle messages
$message = isset($_GET['message']) ? sanitize_text_field(wp_unslash($_GET['message'])) : '';
?>

<div class="wrap dbrd-admin-wrap">
    <h1 class="wp-heading-inline">
        <?php esc_html_e('All Links', 'deviceredirect24'); ?>
    </h1>

    <a href="<?php echo esc_url(admin_url('admin.php?page=dbrd-add-link')); ?>" class="page-title-action">
        <?php esc_html_e('Add New', 'deviceredirect24'); ?>
    </a>

    <hr class="wp-header-end">

    <?php if ($message === 'link_created'): ?>
        <div class="notice notice-success is-dismissible">
            <p><?php esc_html_e('Link created successfully!', 'deviceredirect24'); ?></p>
        </div>
    <?php elseif ($message === 'link_updated'): ?>
        <div class="notice notice-success is-dismissible">
            <p><?php esc_html_e('Link updated successfully!', 'deviceredirect24'); ?></p>
        </div>
    <?php elseif ($message === 'link_deleted'): ?>
        <div class="notice notice-success is-dismissible">
            <p><?php esc_html_e('Link deleted successfully!', 'deviceredirect24'); ?></p>
        </div>
    <?php endif; ?>

    <!-- Usage Stats -->
    <div class="dbrd-usage-stats">
        <div class="dbrd-stat-box">
            <span class="dbrd-stat-label"><?php esc_html_e('Links', 'deviceredirect24'); ?></span>
            <span class="dbrd-stat-value">
                <?php echo esc_html($usage['links_used']); ?> /
                <?php echo $usage['links_limit'] === 'unlimited' ? '∞' : esc_html($usage['links_limit']); ?>
            </span>
        </div>

        <div class="dbrd-stat-box">
            <span class="dbrd-stat-label"><?php esc_html_e('Total Clicks', 'deviceredirect24'); ?></span>
            <span class="dbrd-stat-value">
                <?php echo esc_html($usage['clicks_used']); ?> /
                <?php echo $usage['clicks_limit'] === 'unlimited' ? '∞' : esc_html($usage['clicks_limit']); ?>
            </span>
        </div>
    </div>

    <?php if (empty($links)): ?>
        <!-- Empty State -->
        <div class="dbrd-empty-state">
            <div class="dbrd-empty-icon">🔗</div>
            <h2><?php esc_html_e('No links yet', 'deviceredirect24'); ?></h2>
            <p><?php esc_html_e('Create your first smart link to start tracking clicks and redirecting users based on their device.', 'deviceredirect24'); ?></p>
            <a href="<?php echo esc_url(admin_url('admin.php?page=dbrd-add-link')); ?>" class="button button-primary button-large">
                <?php esc_html_e('Create Your First Link', 'deviceredirect24'); ?>
            </a>
        </div>
    <?php else: ?>
        <!-- Links Table -->
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e('Name', 'deviceredirect24'); ?></th>
                    <th><?php esc_html_e('Short Link', 'deviceredirect24'); ?></th>
                    <th><?php esc_html_e('Clicks', 'deviceredirect24'); ?></th>
                    <th><?php esc_html_e('Status', 'deviceredirect24'); ?></th>
                    <th><?php esc_html_e('Created', 'deviceredirect24'); ?></th>
                    <th><?php esc_html_e('Actions', 'deviceredirect24'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($links as $link):
                    $link_url = DBRD_Router::get_link_url($link->slug);
                    $clicks = DBRD_Database::get_link_clicks($link->id);
                    $edit_url = wp_nonce_url(
                        admin_url('admin.php?page=dbrd-add-link&edit=' . intval($link->id)),
                        'dbrd_edit_link'
                    );
                    $stats_url = wp_nonce_url(
                        admin_url('admin.php?page=dbrd-analytics&link_id=' . intval($link->id)),
                        'dbrd_view_stats'
                    );
                ?>
                <tr>
                    <td>
                        <strong><?php echo esc_html($link->name); ?></strong>
                    </td>
                    <td>
                        <code class="dbrd-link-url"><?php echo esc_html($link_url); ?></code>
                        <button class="button button-small dbrd-copy-btn" data-url="<?php echo esc_attr($link_url); ?>">
                            <?php esc_html_e('Copy', 'deviceredirect24'); ?>
                        </button>
                    </td>
                    <td>
                        <strong><?php echo esc_html(number_format($clicks)); ?></strong>
                    </td>
                    <td>
                        <?php if ($link->is_active): ?>
                            <span class="dbrd-status dbrd-status-active"><?php esc_html_e('Active', 'deviceredirect24'); ?></span>
                        <?php else: ?>
                            <span class="dbrd-status dbrd-status-inactive"><?php esc_html_e('Inactive', 'deviceredirect24'); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo esc_html(date_i18n(get_option('date_format'), strtotime($link->created_at))); ?>
                    </td>
                    <td>
                        <a href="<?php echo esc_url($stats_url); ?>">
                            <?php esc_html_e('Stats', 'deviceredirect24'); ?>
                        </a> |
                        <a href="<?php echo esc_url($edit_url); ?>">
                            <?php esc_html_e('Edit', 'deviceredirect24'); ?>
                        </a> |
                        <a href="#" class="dbrd-delete-link" data-link-id="<?php echo esc_attr($link->id); ?>" data-link-name="<?php echo esc_attr($link->name); ?>">
                            <?php esc_html_e('Delete', 'deviceredirect24'); ?>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<!-- Delete Confirmation Form (hidden) -->
<form method="post" id="dbrd-delete-form" style="display:none;">
    <?php wp_nonce_field('dbrd_link_action', 'dbrd_nonce'); ?>
    <input type="hidden" name="dbrd_action" value="delete_link">
    <input type="hidden" name="link_id" id="dbrd-delete-link-id">
</form>
