<?php
/**
 * Admin Main Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class DBRD_Admin {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('admin_init', array($this, 'handle_form_submissions'));
        add_action('admin_footer', array($this, 'add_donate_link_target_blank'));
    }
    
    /**
     * Add target="_blank" to donate link
     */
    public function add_donate_link_target_blank() {
        $script = "jQuery(document).ready(function($) {
            $('#toplevel_page_dbrd-links .wp-submenu a[href*=\"dailyuseful.tools/donate\"]').attr('target', '_blank');
        });";
        wp_add_inline_script('jquery', $script);
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Main menu
        add_menu_page(
            esc_html__('DeviceRedirect24', 'deviceredirect24'),
            esc_html__('DeviceRedirect24', 'deviceredirect24'),
            'manage_options',
            'dbrd-links',
            array($this, 'render_links_page'),
            'dashicons-admin-links',
            30
        );
        
        // All Links submenu
        add_submenu_page(
            'dbrd-links',
            esc_html__('All Links', 'deviceredirect24'),
            esc_html__('All Links', 'deviceredirect24'),
            'manage_options',
            'dbrd-links',
            array($this, 'render_links_page')
        );
        
        // Add New submenu
        add_submenu_page(
            'dbrd-links',
            esc_html__('Add New Link', 'deviceredirect24'),
            esc_html__('Add New', 'deviceredirect24'),
            'manage_options',
            'dbrd-add-link',
            array($this, 'render_add_link_page')
        );
        
        // Analytics submenu
        add_submenu_page(
            'dbrd-links',
            esc_html__('Analytics', 'deviceredirect24'),
            esc_html__('Analytics', 'deviceredirect24'),
            'manage_options',
            'dbrd-analytics',
            array($this, 'render_analytics_page')
        );
        
        // Settings submenu
        add_submenu_page(
            'dbrd-links',
            esc_html__('Settings', 'deviceredirect24'),
            esc_html__('Settings', 'deviceredirect24'),
            'manage_options',
            'dbrd-settings',
            array($this, 'render_settings_page')
        );
        
        // Donate submenu (external link)
        add_submenu_page(
            'dbrd-links',
            esc_html__('Donate', 'deviceredirect24'),
            '<span style="color:#FCB214">❤️ ' . esc_html__('Donate', 'deviceredirect24') . '</span>',
            'manage_options',
            'https://dailyuseful.tools/donate/',
            ''
        );
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        // Only load on our plugin pages
        if (strpos($hook, 'dbrd-') === false && strpos($hook, 'link-router') === false) {
            return;
        }
        
        wp_enqueue_style(
            'dbrd-admin-css',
            DBRD_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            DBRD_VERSION
        );
        
        wp_enqueue_script(
            'dbrd-admin-js',
            DBRD_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            DBRD_VERSION,
            true
        );
        
        wp_localize_script('dbrd-admin-js', 'dbrdAdmin', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('dbrd-admin-nonce'),
        ));
    }
    
    /**
     * Handle form submissions
     */
    public function handle_form_submissions() {
        // Handle link creation/editing
        if (isset($_POST['dbrd_action']) && isset($_POST['dbrd_nonce'])) {
            if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dbrd_nonce'])), 'dbrd_link_action')) {
                wp_die(esc_html__('Security check failed', 'deviceredirect24'));
            }

            if (!current_user_can('manage_options')) {
                wp_die(esc_html__('You do not have permission to perform this action.', 'deviceredirect24'));
            }
            
            $action = sanitize_text_field(wp_unslash($_POST['dbrd_action']));
            
            if ($action === 'create_link') {
                $this->handle_create_link();
            } elseif ($action === 'update_link') {
                $this->handle_update_link();
            } elseif ($action === 'delete_link') {
                $this->handle_delete_link();
            }
        }
        
        // Handle delete all data
        if (isset($_POST['dbrd_delete_all_data']) && isset($_POST['dbrd_delete_all_nonce'])) {
            if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dbrd_delete_all_nonce'])), 'dbrd_delete_all_action')) {
                wp_die(esc_html__('Security check failed', 'deviceredirect24'));
            }

            if (!current_user_can('manage_options')) {
                wp_die(esc_html__('You do not have permission to perform this action.', 'deviceredirect24'));
            }

            // Delete all plugin data
            DBRD_Database::delete_all_data();

            $redirect = add_query_arg(array(
                'page' => 'dbrd-settings',
                'message' => 'data_deleted',
            ), admin_url('admin.php'));

            wp_safe_redirect($redirect);
            exit;
        }
    }
    
    /**
     * Handle link creation
     */
    private function handle_create_link() {
        $user_id = get_current_user_id();

        // Validate and sanitize input
        $name = isset($_POST['link_name']) ? sanitize_text_field(wp_unslash($_POST['link_name'])) : '';
        $slug = isset($_POST['link_slug']) ? DBRD_Router::sanitize_slug(wp_unslash($_POST['link_slug'])) : '';
        $ios_url = isset($_POST['ios_url']) ? esc_url_raw(wp_unslash($_POST['ios_url'])) : '';
        $android_url = isset($_POST['android_url']) ? esc_url_raw(wp_unslash($_POST['android_url'])) : '';
        $desktop_url = isset($_POST['desktop_url']) ? esc_url_raw(wp_unslash($_POST['desktop_url'])) : '';

        // Desktop URL is required
        if (empty($desktop_url)) {
            wp_safe_redirect(add_query_arg(array(
                'page' => 'dbrd-add-link',
                'error' => 'desktop_required',
            ), admin_url('admin.php')));
            exit;
        }

        // Check if slug is available
        if (!DBRD_Router::is_slug_available($slug)) {
            wp_safe_redirect(add_query_arg(array(
                'page' => 'dbrd-add-link',
                'error' => 'slug_exists',
            ), admin_url('admin.php')));
            exit;
        }

        // Create link
        $link_id = DBRD_Database::create_link(array(
            'user_id' => $user_id,
            'name' => $name,
            'slug' => $slug,
            'ios_url' => $ios_url,
            'android_url' => $android_url,
            'desktop_url' => $desktop_url,
        ));

        if ($link_id) {
            wp_safe_redirect(add_query_arg(array(
                'page' => 'dbrd-links',
                'message' => 'link_created',
            ), admin_url('admin.php')));
        } else {
            wp_safe_redirect(add_query_arg(array(
                'page' => 'dbrd-add-link',
                'error' => 'create_failed',
            ), admin_url('admin.php')));
        }
        exit;
    }
    
    /**
     * Handle link update
     */
    private function handle_update_link() {
        $link_id = isset($_POST['link_id']) ? intval($_POST['link_id']) : 0;

        $data = array(
            'name' => isset($_POST['link_name']) ? sanitize_text_field(wp_unslash($_POST['link_name'])) : '',
            'slug' => isset($_POST['link_slug']) ? DBRD_Router::sanitize_slug(wp_unslash($_POST['link_slug'])) : '',
            'ios_url' => isset($_POST['ios_url']) ? esc_url_raw(wp_unslash($_POST['ios_url'])) : '',
            'android_url' => isset($_POST['android_url']) ? esc_url_raw(wp_unslash($_POST['android_url'])) : '',
            'desktop_url' => isset($_POST['desktop_url']) ? esc_url_raw(wp_unslash($_POST['desktop_url'])) : '',
        );

        DBRD_Database::update_link($link_id, $data);

        wp_safe_redirect(add_query_arg(array(
            'page' => 'dbrd-links',
            'message' => 'link_updated',
        ), admin_url('admin.php')));
        exit;
    }
    
    /**
     * Handle link deletion
     */
    private function handle_delete_link() {
        $link_id = isset($_POST['link_id']) ? intval($_POST['link_id']) : 0;
        DBRD_Database::delete_link($link_id);

        wp_safe_redirect(add_query_arg(array(
            'page' => 'dbrd-links',
            'message' => 'link_deleted',
        ), admin_url('admin.php')));
        exit;
    }
    
    /**
     * Render pages
     */
    public function render_links_page() {
        require_once DBRD_PLUGIN_DIR . 'admin/views/links-list.php';
    }
    
    public function render_add_link_page() {
        require_once DBRD_PLUGIN_DIR . 'admin/views/add-link.php';
    }
    
    public function render_analytics_page() {
        require_once DBRD_PLUGIN_DIR . 'admin/views/analytics.php';
    }
    
    public function render_settings_page() {
        require_once DBRD_PLUGIN_DIR . 'admin/views/settings.php';
    }
    
}
