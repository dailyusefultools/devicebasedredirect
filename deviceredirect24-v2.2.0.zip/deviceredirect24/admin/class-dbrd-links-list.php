<?php
/**
 * Links List Table Class
 * Extends WP_List_Table for better admin interface
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class DBRD_Links_List_Table extends WP_List_Table {
    
    public function __construct() {
        parent::__construct(array(
            'singular' => 'link',
            'plural' => 'links',
            'ajax' => false,
        ));
    }
    
    public function get_columns() {
        return array(
            'cb' => '<input type="checkbox" />',
            'name' => esc_html__('Name', 'deviceredirect24'),
            'url' => esc_html__('Short Link', 'deviceredirect24'),
            'clicks' => esc_html__('Clicks', 'deviceredirect24'),
            'status' => esc_html__('Status', 'deviceredirect24'),
            'date' => esc_html__('Created', 'deviceredirect24'),
        );
    }
    
    public function column_cb($item) {
        return sprintf('<input type="checkbox" name="link[]" value="%s" />', $item->id);
    }
    
    public function column_name($item) {
        $edit_url = admin_url('admin.php?page=dbrd-add-link&edit=' . $item->id);
        $delete_url = wp_nonce_url(
            admin_url('admin.php?page=dbrd-links&action=delete&link=' . $item->id),
            'dbr_delete_link_' . $item->id
        );
        
        $actions = array(
            'edit' => sprintf('<a href="%s">%s</a>', $edit_url, esc_html__('Edit', 'deviceredirect24')),
            'delete' => sprintf(
                '<a href="%s" class="dbrd-delete-link" data-link-id="%d" data-link-name="%s">%s</a>',
                $delete_url,
                $item->id,
                esc_attr($item->name),
                esc_html__('Delete', 'deviceredirect24')
            ),
        );
        
        return sprintf('<strong>%s</strong>%s', $item->name, $this->row_actions($actions));
    }
    
    public function column_url($item) {
        $url = DBRD_Router::get_link_url($item->slug);
        return sprintf(
            '<code class="dbrd-link-url">%s</code> <button class="button button-small dbrd-copy-btn" data-url="%s">%s</button>',
            esc_html($url),
            esc_attr($url),
            esc_html__('Copy', 'deviceredirect24')
        );
    }
    
    public function column_clicks($item) {
        $clicks = DBRD_Database::get_link_clicks($item->id);
        $stats_url = admin_url('admin.php?page=dbrd-analytics&link_id=' . $item->id);
        
        return sprintf(
            '<a href="%s"><strong>%s</strong></a>',
            $stats_url,
            number_format($clicks)
        );
    }
    
    public function column_status($item) {
        if ($item->is_active) {
            return '<span class="dbrd-status dbrd-status-active">' . esc_html__('Active', 'deviceredirect24') . '</span>';
        }
        return '<span class="dbrd-status dbrd-status-inactive">' . esc_html__('Inactive', 'deviceredirect24') . '</span>';
    }
    
    public function column_date($item) {
        return date_i18n(get_option('date_format'), strtotime($item->created_at));
    }
    
    public function prepare_items() {
        $user_id = get_current_user_id();
        $links = DBRD_Database::get_user_links($user_id);
        
        $this->items = $links;
        
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = array();
        
        $this->_column_headers = array($columns, $hidden, $sortable);
    }
}
