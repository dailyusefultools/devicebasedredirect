<?php
/**
 * Router Class - Handles device detection and redirects
 */

if (!defined('ABSPATH')) {
    exit;
}

class DBRD_Router {
    
    /**
     * Handle redirect requests
     */
    public static function handle_redirect() {
        // Get query var
        $slug = get_query_var('dbrd_link');
        
        if (empty($slug)) {
            return;
        }
        
        $slug = sanitize_text_field($slug);
        
        // Get link from database
        $link = DBRD_Database::get_link_by_slug($slug);
        
        if (!$link) {
            // Link not found - show 404
            global $wp_query;
            $wp_query->set_404();
            status_header(404);
            return;
        }
        
        // Detect device
        $device_type = self::detect_device();
        
        // Get redirect URL based on device
        $redirect_url = self::get_redirect_url($link, $device_type);
        
        if (!$redirect_url) {
            // No URL configured for this device - show error page
            wp_die(
                esc_html__('This link is not configured for your device.', 'deviceredirect24'),
                esc_html__('Link Not Available', 'deviceredirect24'),
                array('response' => 404)
            );
        }
        
        // Record the click (only if within limits for free users)
        // Get link owner to check limits
        $link_owner = $link->user_id;
        
        // Check if user can track more clicks
        if (DBRD_License::can_track_clicks($link_owner)) {
            DBRD_Database::record_click($link->id, $device_type);
        }
        // Note: Link still redirects even if limit reached!
        
        // Perform redirect
        wp_redirect($redirect_url, 302);
        exit;
    }
    
    /**
     * Detect device type from user agent
     */
    public static function detect_device() {
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';

        // iOS devices (iPhone, iPad, iPod)
        if (preg_match('/iPhone|iPad|iPod/i', $user_agent)) {
            return 'ios';
        }

        // Android devices
        if (preg_match('/Android/i', $user_agent)) {
            return 'android';
        }

        // Everything else is desktop
        return 'desktop';
    }
    
    /**
     * Get redirect URL for device with Desktop as fallback
     */
    private static function get_redirect_url($link, $device_type) {
        $url = null;
        
        switch ($device_type) {
            case 'ios':
                $url = !empty($link->ios_url) ? $link->ios_url : $link->desktop_url;
                break;
            case 'android':
                $url = !empty($link->android_url) ? $link->android_url : $link->desktop_url;
                break;
            case 'desktop':
                $url = $link->desktop_url;
                break;
        }
        
        return $url;
    }
    
    /**
     * Generate full link URL
     */
    public static function get_link_url($slug) {
        return home_url('/go/' . $slug);
    }
    
    /**
     * Check if slug is available
     */
    public static function is_slug_available($slug, $exclude_id = null) {
        global $wpdb;
        $table = $wpdb->prefix . 'dbr_links';
        
        $sql = "SELECT COUNT(*) FROM $table WHERE slug = %s";
        $params = array($slug);
        
        if ($exclude_id) {
            $sql .= " AND id != %d";
            $params[] = $exclude_id;
        }
        
        $count = $wpdb->get_var($wpdb->prepare($sql, $params));
        
        return $count == 0;
    }
    
    /**
     * Sanitize slug
     */
    public static function sanitize_slug($slug) {
        // Convert to lowercase
        $slug = strtolower($slug);
        
        // Replace spaces and special chars with dash
        $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
        
        // Remove leading/trailing dashes
        $slug = trim($slug, '-');
        
        // Limit length
        $slug = substr($slug, 0, 100);
        
        return $slug;
    }
}
