<?php
/**
 * License Management Class
 *
 * This is a FREE version - all features are unlimited.
 */

if (!defined('ABSPATH')) {
    exit;
}

class DBRD_License {

    /**
     * Check if user has pro license
     * FREE VERSION - always returns true for unlimited access
     */
    public static function is_pro() {
        return true;
    }

    /**
     * Get license status
     */
    public static function get_status() {
        return 'free';
    }

    /**
     * Check if user can create more links
     * FREE VERSION - always allowed
     */
    public static function can_create_link($user_id) {
        return array('allowed' => true);
    }

    /**
     * Check if user can track more clicks
     * FREE VERSION - always allowed
     */
    public static function can_track_clicks($user_id) {
        return true;
    }

    /**
     * Check if user has exceeded monthly click limit
     * FREE VERSION - no limits
     */
    public static function check_click_limit($user_id) {
        return array('exceeded' => false);
    }

    /**
     * Get usage stats
     */
    public static function get_usage_stats($user_id) {
        $user_links = DBRD_Database::get_user_links($user_id);
        $total_clicks = DBRD_Database::get_user_total_clicks($user_id);

        return array(
            'is_pro' => true,
            'links_used' => count($user_links),
            'links_limit' => 'unlimited',
            'clicks_used' => $total_clicks,
            'clicks_limit' => 'unlimited',
            'limit_reached' => false,
        );
    }
}
