<?php
/**
 * Database Management Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class DBRD_Database {
    
    /**
     * Create plugin database tables
     */
    public static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Links table
        $links_table = $wpdb->prefix . 'dbr_links';
        $sql_links = "CREATE TABLE IF NOT EXISTS $links_table (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            slug varchar(255) NOT NULL,
            name varchar(255) NOT NULL,
            ios_url varchar(2048) DEFAULT NULL,
            android_url varchar(2048) DEFAULT NULL,
            desktop_url varchar(2048) NOT NULL,
            is_active tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug),
            KEY user_id (user_id),
            KEY is_active (is_active)
        ) $charset_collate;";
        
        // Analytics/Clicks table
        $clicks_table = $wpdb->prefix . 'dbr_clicks';
        $sql_clicks = "CREATE TABLE IF NOT EXISTS $clicks_table (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            link_id bigint(20) UNSIGNED NOT NULL,
            device_type varchar(20) NOT NULL,
            user_agent text DEFAULT NULL,
            ip_address varchar(45) DEFAULT NULL,
            referer varchar(2048) DEFAULT NULL,
            clicked_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY link_id (link_id),
            KEY device_type (device_type),
            KEY clicked_at (clicked_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_links);
        dbDelta($sql_clicks);
    }
    
    /**
     * Get link by slug
     */
    public static function get_link_by_slug($slug) {
        global $wpdb;
        $table = $wpdb->prefix . 'dbr_links';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE slug = %s AND is_active = 1 LIMIT 1",
            $slug
        ));
    }
    
    /**
     * Get all links for a user
     */
    public static function get_user_links($user_id, $active_only = false) {
        global $wpdb;
        $table = $wpdb->prefix . 'dbr_links';
        
        $sql = "SELECT * FROM $table WHERE user_id = %d";
        if ($active_only) {
            $sql .= " AND is_active = 1";
        }
        $sql .= " ORDER BY created_at DESC";
        
        return $wpdb->get_results($wpdb->prepare($sql, $user_id));
    }
    
    /**
     * Create new link
     */
    public static function create_link($data) {
        global $wpdb;
        $table = $wpdb->prefix . 'dbr_links';
        
        $wpdb->insert($table, array(
            'user_id' => $data['user_id'],
            'slug' => $data['slug'],
            'name' => $data['name'],
            'ios_url' => $data['ios_url'] ?? null,
            'android_url' => $data['android_url'] ?? null,
            'desktop_url' => $data['desktop_url'],
            'is_active' => $data['is_active'] ?? 1,
        ));
        
        return $wpdb->insert_id;
    }
    
    /**
     * Update link
     */
    public static function update_link($id, $data) {
        global $wpdb;
        $table = $wpdb->prefix . 'dbr_links';
        
        return $wpdb->update(
            $table,
            $data,
            array('id' => $id)
        );
    }
    
    /**
     * Delete link
     */
    public static function delete_link($id) {
        global $wpdb;
        $table = $wpdb->prefix . 'dbr_links';
        
        return $wpdb->delete($table, array('id' => $id));
    }
    
    /**
     * Record click
     */
    public static function record_click($link_id, $device_type) {
        global $wpdb;
        $table = $wpdb->prefix . 'dbr_clicks';

        $wpdb->insert($table, array(
            'link_id' => $link_id,
            'device_type' => $device_type,
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : null,
            'ip_address' => self::get_client_ip(),
            'referer' => isset($_SERVER['HTTP_REFERER']) ? esc_url_raw(wp_unslash($_SERVER['HTTP_REFERER'])) : null,
        ));

        return $wpdb->insert_id;
    }
    
    /**
     * Get click count for link
     */
    public static function get_link_clicks($link_id, $date_from = null, $date_to = null) {
        global $wpdb;
        $table = $wpdb->prefix . 'dbr_clicks';
        
        $sql = "SELECT COUNT(*) FROM $table WHERE link_id = %d";
        $params = array($link_id);
        
        if ($date_from) {
            $sql .= " AND clicked_at >= %s";
            $params[] = $date_from;
        }
        
        if ($date_to) {
            $sql .= " AND clicked_at <= %s";
            $params[] = $date_to;
        }
        
        return $wpdb->get_var($wpdb->prepare($sql, $params));
    }
    
    /**
     * Get clicks by device type
     */
    public static function get_clicks_by_device($link_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'dbr_clicks';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT device_type, COUNT(*) as count 
            FROM $table 
            WHERE link_id = %d 
            GROUP BY device_type",
            $link_id
        ));
    }
    
    /**
     * Get total clicks for user (for usage limits)
     */
    public static function get_user_monthly_clicks($user_id) {
        global $wpdb;
        $links_table = $wpdb->prefix . 'dbr_links';
        $clicks_table = $wpdb->prefix . 'dbr_clicks';
        
        $first_day = date('Y-m-01 00:00:00');
        
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $clicks_table c
            INNER JOIN $links_table l ON c.link_id = l.id
            WHERE l.user_id = %d AND c.clicked_at >= %s",
            $user_id,
            $first_day
        ));
    }
    
    /**
     * Get total all-time clicks for user (for permanent free tier limit)
     */
    public static function get_user_total_clicks($user_id) {
        global $wpdb;
        $links_table = $wpdb->prefix . 'dbr_links';
        $clicks_table = $wpdb->prefix . 'dbr_clicks';
        
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $clicks_table c
            INNER JOIN $links_table l ON c.link_id = l.id
            WHERE l.user_id = %d",
            $user_id
        ));
    }
    
    /**
     * Get client IP address
     */
    private static function get_client_ip() {
        $ip = '';

        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = sanitize_text_field(wp_unslash($_SERVER['HTTP_CLIENT_IP']));
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = sanitize_text_field(wp_unslash($_SERVER['HTTP_X_FORWARDED_FOR']));
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR']));
        }

        return $ip;
    }

    /**
     * Delete all plugin data (nuclear option)
     */
    public static function delete_all_data() {
        global $wpdb;

        $links_table = $wpdb->prefix . 'dbr_links';
        $clicks_table = $wpdb->prefix . 'dbr_clicks';

        // Delete all clicks - using $wpdb->query is safe here since table names are defined internally
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->query("TRUNCATE TABLE {$clicks_table}");

        // Delete all links
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->query("TRUNCATE TABLE {$links_table}");

        // Delete plugin options
        delete_option('dbrd_flush_rewrite_rules_flag');

        return true;
    }
}
