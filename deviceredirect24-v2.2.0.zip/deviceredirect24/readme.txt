=== DeviceRedirect24 ===
Contributors: deviceredirect24
Tags: redirect, device detection, mobile, ios, android, app marketing, link shortener
Requires at least: 5.8
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 2.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Create smart links that automatically redirect users to different URLs based on their device (iOS, Android, Desktop). Perfect for app marketing!

== Description ==

**DeviceRedirect24** makes it easy to create smart links that automatically detect your visitor's device and redirect them to the appropriate destination. Perfect for app developers, marketers, and anyone who needs different landing pages for mobile and desktop users.

= Use Cases =

* **App Marketing**: Send iPhone users to the App Store, Android users to Google Play, and desktop users to your website
* **Platform-Specific Content**: Direct users to device-optimized content
* **A/B Testing**: Test different landing pages for different devices
* **Affiliate Marketing**: Send mobile users to mobile-optimized affiliate pages

= Key Features =

**Simple & Intuitive:**
* Desktop URL is required and serves as automatic fallback
* Leave iOS/Android URLs empty if you don't need them
* No complicated configuration - just works!

**100% FREE - All Features Included:**
* Unlimited links
* Unlimited clicks
* Device detection (iOS, Android, Desktop)
* Automatic fallback to Desktop URL
* Full analytics with charts
* Simple, clean URLs (yoursite.com/go/linkname)
* Easy-to-use dashboard

= How It Works =

1. **Create a Link**: Give your link a name and short link code
2. **Set Desktop URL**: Your website URL (required - used as fallback)
3. **Optional**: Add iOS and/or Android URLs
4. **Share**: Use your short link everywhere!
5. **Track**: Monitor clicks and device distribution

= Smart Fallback Logic =

The Desktop URL is always required and serves as the fallback:

* **iOS URL filled**: iPhone/iPad → iOS URL, Others → Desktop URL
* **Android URL filled**: Android → Android URL, Others → Desktop URL
* **Both filled**: iOS → iOS URL, Android → Android URL, Desktop → Desktop URL
* **Neither filled**: Everyone → Desktop URL (works like a normal redirect)

This means you'll never have broken links - there's always a destination!

= Example Scenarios =

**Scenario 1: App with both iOS and Android**
* iOS URL: https://apps.apple.com/app/myapp
* Android URL: https://play.google.com/store/apps/myapp
* Desktop URL: https://mywebsite.com
Result: Perfect! Each device goes to the right place.

**Scenario 2: iOS app only**
* iOS URL: https://apps.apple.com/app/myapp
* Android URL: (empty)
* Desktop URL: https://mywebsite.com
Result: iPhone users go to App Store, everyone else goes to your website!

**Scenario 3: Simple website redirect**
* iOS URL: (empty)
* Android URL: (empty)
* Desktop URL: https://mywebsite.com
Result: Everyone goes to your website - works like a normal short link!

= Privacy & Data Handling =

This plugin stores all data locally in your WordPress database. No external services are used.

**Data collected (stored locally only):**
* Link configurations (URLs, names, slugs)
* Anonymous click analytics (device type, timestamp)
* IP addresses (for basic analytics, stored in your database)

**No external connections:**
* All processing happens on your server
* No data is sent to third parties
* GDPR compliant by design

== Installation ==

= Automatic Installation =

1. Log in to your WordPress admin panel
2. Go to Plugins → Add New
3. Search for "DeviceRedirect24"
4. Click "Install Now" and then "Activate"

= Manual Installation =

1. Download the plugin ZIP file
2. Log in to your WordPress admin panel
3. Go to Plugins → Add New → Upload Plugin
4. Choose the ZIP file and click "Install Now"
5. Activate the plugin

= After Installation =

1. Go to DeviceRedirect24 → Add New
2. Create your first smart link
3. Desktop URL is required, iOS/Android are optional
4. Start tracking clicks!

== Frequently Asked Questions ==

= Why is Desktop URL required? =

Desktop URL serves as the universal fallback. If a user visits from a device without a specific URL configured, they'll be redirected to the Desktop URL instead of seeing an error. Since you're using WordPress, you already have a website!

= What if I leave iOS and Android URLs empty? =

No problem! All users will be redirected to your Desktop URL. The plugin works perfectly as a simple redirect tool too.

= Can I have iOS URL but no Android URL? =

Absolutely! iPhone/iPad users will go to the App Store, while Android and desktop users will go to your website (Desktop URL).

= How many links can I create? =

Unlimited! This is a completely free plugin with no restrictions.

= Is there a monthly fee? =

No! This plugin is 100% free with all features included.

= Can I use this for affiliate links? =

Yes! Just make sure you comply with the terms of service of your affiliate programs.

= Does this work with any theme? =

Yes! The plugin works with any WordPress theme.

= Where is the data stored? =

All data is stored in your WordPress database. Nothing is sent to external servers.

== Screenshots ==

1. Main dashboard showing all your links and usage stats
2. Create new link - Desktop URL required, device URLs optional
3. Analytics dashboard with click statistics
4. Detailed link analytics with device breakdown

== Changelog ==

= 2.2.0 =
* Security: Fixed all nonce verification to use sanitize_text_field(wp_unslash())
* Security: Added proper escaping for all output (esc_url, esc_attr, esc_html)
* Security: Fixed inline JavaScript to use wp_add_inline_script()
* Security: Added nonce validation for GET parameters
* Security: Sanitized HTTP_USER_AGENT and HTTP_REFERER inputs
* Security: Added current_user_can() checks alongside nonce verification
* Fixed: Consistent option naming with dbrd_ prefix
* Fixed: Used wp_safe_redirect() instead of wp_redirect()
* Improved: Better WordPress.org security guidelines compliance
* Removed: External license verification (plugin is now 100% free)

= 2.1.3 =
* Security: Sanitized HTTP_REFERER and HTTP_USER_AGENT inputs
* Security: Updated json_encode to wp_json_encode for proper escaping
* Fixed: Text domain now matches plugin slug (deviceredirect24)
* Updated: Tested up to WordPress 6.9
* Updated: All links now point to dailyuseful.tools
* Improved: Better compliance with WordPress.org security guidelines

= 2.1.2 =
* Changed: Checkout URL now points to dailyuseful.tools
* Improved: Centralized checkout for better flexibility

= 2.1.1 =
* Fixed: Upgrade buttons now point directly to checkout page

= 2.1.0 =
* Initial release
* Device detection for iOS, Android, and Desktop
* Smart redirect functionality with automatic fallback
* Desktop URL required as universal fallback
* Full analytics dashboard with charts
* Unlimited links and clicks

== Upgrade Notice ==

= 2.2.0 =
Important security improvements and WordPress.org compliance updates. All users should update immediately.

= 2.1.3 =
Security improvements and WordPress.org compliance updates. All users should update.

== Support ==

For support, please visit [dailyuseful.tools/support](https://dailyuseful.tools/support)
