<?php
/**
 * Analytics Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class DBRD_Analytics {
    
    /**
     * Get overview stats for user
     */
    public static function get_user_overview($user_id) {
        global $wpdb;
        $links_table = $wpdb->prefix . 'dbr_links';
        $clicks_table = $wpdb->prefix . 'dbr_clicks';
        
        // Total links
        $total_links = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $links_table WHERE user_id = %d",
            $user_id
        ));
        
        // Total clicks (all time)
        $total_clicks = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $clicks_table c
            INNER JOIN $links_table l ON c.link_id = l.id
            WHERE l.user_id = %d",
            $user_id
        ));
        
        // This month's clicks
        $first_day = date('Y-m-01 00:00:00');
        $monthly_clicks = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $clicks_table c
            INNER JOIN $links_table l ON c.link_id = l.id
            WHERE l.user_id = %d AND c.clicked_at >= %s",
            $user_id,
            $first_day
        ));
        
        // Today's clicks
        $today_start = date('Y-m-d 00:00:00');
        $today_clicks = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $clicks_table c
            INNER JOIN $links_table l ON c.link_id = l.id
            WHERE l.user_id = %d AND c.clicked_at >= %s",
            $user_id,
            $today_start
        ));
        
        // Active links
        $active_links = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $links_table WHERE user_id = %d AND is_active = 1",
            $user_id
        ));
        
        return array(
            'total_links' => intval($total_links),
            'active_links' => intval($active_links),
            'total_clicks' => intval($total_clicks),
            'monthly_clicks' => intval($monthly_clicks),
            'today_clicks' => intval($today_clicks),
        );
    }
    
    /**
     * Get detailed stats for a specific link
     */
    public static function get_link_stats($link_id, $days = 30) {
        global $wpdb;
        $clicks_table = $wpdb->prefix . 'dbr_clicks';
        
        $date_from = date('Y-m-d 00:00:00', strtotime("-$days days"));
        
        // Total clicks
        $total_clicks = DBRD_Database::get_link_clicks($link_id, $date_from);
        
        // Clicks by device
        $device_stats = DBRD_Database::get_clicks_by_device($link_id);
        
        $devices = array(
            'ios' => 0,
            'android' => 0,
            'desktop' => 0,
        );
        
        foreach ($device_stats as $stat) {
            $devices[$stat->device_type] = intval($stat->count);
        }
        
        // Daily clicks (last 30 days)
        $daily_clicks = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(clicked_at) as date, COUNT(*) as clicks
            FROM $clicks_table
            WHERE link_id = %d AND clicked_at >= %s
            GROUP BY DATE(clicked_at)
            ORDER BY date ASC",
            $link_id,
            $date_from
        ));
        
        // Fill in missing days with 0
        $daily_data = array();
        for ($i = $days - 1; $i >= 0; $i--) {
            $date = date('Y-m-d', strtotime("-$i days"));
            $daily_data[$date] = 0;
        }
        
        foreach ($daily_clicks as $day) {
            $daily_data[$day->date] = intval($day->clicks);
        }
        
        return array(
            'total_clicks' => intval($total_clicks),
            'devices' => $devices,
            'daily_clicks' => $daily_data,
        );
    }
    
    /**
     * Get top performing links for user
     */
    public static function get_top_links($user_id, $limit = 5) {
        global $wpdb;
        $links_table = $wpdb->prefix . 'dbr_links';
        $clicks_table = $wpdb->prefix . 'dbr_clicks';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT l.id, l.name, l.slug, COUNT(c.id) as clicks
            FROM $links_table l
            LEFT JOIN $clicks_table c ON l.id = c.link_id
            WHERE l.user_id = %d
            GROUP BY l.id
            ORDER BY clicks DESC
            LIMIT %d",
            $user_id,
            $limit
        ));
    }
}
