/**
 * Device Based Redirect - Admin JavaScript
 */

jQuery(document).ready(function($) {
    
    /**
     * Copy link URL to clipboard
     */
    $('.dbrd-copy-btn').on('click', function(e) {
        e.preventDefault();
        
        var url = $(this).data('url');
        var button = $(this);
        
        // Create temporary input
        var temp = $('<input>');
        $('body').append(temp);
        temp.val(url).select();
        
        try {
            document.execCommand('copy');
            
            // Visual feedback
            var originalText = button.text();
            button.text('✓ Copied!');
            button.addClass('button-primary');
            
            setTimeout(function() {
                button.text(originalText);
                button.removeClass('button-primary');
            }, 2000);
        } catch (err) {
            alert('Failed to copy. Please copy manually: ' + url);
        }
        
        temp.remove();
    });
    
    /**
     * Delete link confirmation
     */
    $('.dbrd-delete-link').on('click', function(e) {
        e.preventDefault();
        
        var linkId = $(this).data('link-id');
        var linkName = $(this).data('link-name');
        
        if (confirm('Are you sure you want to delete "' + linkName + '"? This action cannot be undone.')) {
            $('#dbrd-delete-link-id').val(linkId);
            $('#dbrd-delete-form').submit();
        }
    });
    
    /**
     * Slug auto-generation from name
     */
    $('#link_name').on('blur', function() {
        var slugInput = $('#link_slug');
        
        // Only auto-generate if slug is empty
        if (slugInput.val() === '') {
            var name = $(this).val();
            var slug = name
                .toLowerCase()
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/^-+|-+$/g, '');
            
            slugInput.val(slug);
        }
    });
    
    /**
     * Slug validation (realtime)
     */
    $('#link_slug').on('input', function() {
        var val = $(this).val();
        var sanitized = val
            .toLowerCase()
            .replace(/[^a-z0-9-]/g, '');
        
        if (val !== sanitized) {
            $(this).val(sanitized);
        }
    });
    
    /**
     * Chart.js initialization (if on analytics page)
     */
    if (typeof dbrdAnalyticsData.deviceData !== 'undefined') {
        initDeviceChart();
    }
    
    if (typeof dbrdAnalyticsData.dailyData !== 'undefined') {
        initTimelineChart();
    }
    
    /**
     * Initialize device distribution chart
     */
    function initDeviceChart() {
        var ctx = document.getElementById('dbrd-device-chart');
        if (!ctx) return;
        
        // Simple canvas-based chart (no Chart.js dependency)
        var canvas = ctx.getContext('2d');
        var total = dbrdAnalyticsData.deviceData.ios + dbrdAnalyticsData.deviceData.android + dbrdAnalyticsData.deviceData.desktop;
        
        if (total === 0) {
            canvas.fillStyle = '#ddd';
            canvas.fillRect(0, 0, ctx.width, ctx.height);
            canvas.fillStyle = '#666';
            canvas.font = '16px Arial';
            canvas.textAlign = 'center';
            canvas.fillText('No data yet', ctx.width / 2, ctx.height / 2);
            return;
        }
        
        var data = [
            { label: 'iOS', value: dbrdAnalyticsData.deviceData.ios, color: '#2271b1' },
            { label: 'Android', value: dbrdAnalyticsData.deviceData.android, color: '#50c878' },
            { label: 'Desktop', value: dbrdAnalyticsData.deviceData.desktop, color: '#fcb214' }
        ];
        
        // Draw simple bar chart
        var barWidth = (ctx.width / 3) - 40;
        var maxValue = Math.max(dbrdAnalyticsData.deviceData.ios, dbrdAnalyticsData.deviceData.android, dbrdAnalyticsData.deviceData.desktop);
        var heightScale = (ctx.height - 60) / maxValue;
        
        data.forEach(function(item, index) {
            var x = (index * (ctx.width / 3)) + 20;
            var barHeight = item.value * heightScale;
            var y = ctx.height - 40 - barHeight;
            
            // Draw bar
            canvas.fillStyle = item.color;
            canvas.fillRect(x, y, barWidth, barHeight);
            
            // Draw value
            canvas.fillStyle = '#000';
            canvas.font = 'bold 14px Arial';
            canvas.textAlign = 'center';
            canvas.fillText(item.value.toString(), x + (barWidth / 2), y - 5);
            
            // Draw label
            canvas.fillText(item.label, x + (barWidth / 2), ctx.height - 20);
        });
    }
    
    /**
     * Initialize timeline chart
     */
    function initTimelineChart() {
        var ctx = document.getElementById('dbrd-timeline-chart');
        if (!ctx) return;
        
        var canvas = ctx.getContext('2d');
        var dates = Object.keys(dbrdAnalyticsData.dailyData);
        var values = Object.values(dbrdAnalyticsData.dailyData);
        var maxValue = Math.max.apply(null, values);
        
        if (maxValue === 0) {
            canvas.fillStyle = '#ddd';
            canvas.fillRect(0, 0, ctx.width, ctx.height);
            canvas.fillStyle = '#666';
            canvas.font = '16px Arial';
            canvas.textAlign = 'center';
            canvas.fillText('No data yet', ctx.width / 2, ctx.height / 2);
            return;
        }
        
        // Draw simple line chart
        var padding = 40;
        var chartWidth = ctx.width - (padding * 2);
        var chartHeight = ctx.height - (padding * 2);
        var xStep = chartWidth / (dates.length - 1);
        var yScale = chartHeight / maxValue;
        
        // Draw axes
        canvas.strokeStyle = '#ddd';
        canvas.lineWidth = 1;
        canvas.beginPath();
        canvas.moveTo(padding, padding);
        canvas.lineTo(padding, ctx.height - padding);
        canvas.lineTo(ctx.width - padding, ctx.height - padding);
        canvas.stroke();
        
        // Draw line
        canvas.strokeStyle = '#2271b1';
        canvas.lineWidth = 2;
        canvas.beginPath();
        
        values.forEach(function(value, index) {
            var x = padding + (index * xStep);
            var y = (ctx.height - padding) - (value * yScale);
            
            if (index === 0) {
                canvas.moveTo(x, y);
            } else {
                canvas.lineTo(x, y);
            }
        });
        
        canvas.stroke();
        
        // Draw points
        canvas.fillStyle = '#2271b1';
        values.forEach(function(value, index) {
            var x = padding + (index * xStep);
            var y = (ctx.height - padding) - (value * yScale);
            
            canvas.beginPath();
            canvas.arc(x, y, 4, 0, 2 * Math.PI);
            canvas.fill();
        });
        
        // Draw max value label
        canvas.fillStyle = '#666';
        canvas.font = '12px Arial';
        canvas.textAlign = 'right';
        canvas.fillText(maxValue.toString(), padding - 5, padding + 5);
    }
});
