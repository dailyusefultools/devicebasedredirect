<?php
/**
 * Analytics Admin Page
 */

if (!defined('ABSPATH')) {
    exit;
}

$user_id = get_current_user_id();
$overview = DBRD_Analytics::get_user_overview($user_id);
$is_pro = DBRD_License::is_pro();

// Get specific link stats if link_id is provided with valid nonce
$link_id = null;
$link = null;
$link_stats = null;

if (isset($_GET['link_id']) && isset($_GET['_wpnonce'])) {
    if (wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'dbrd_view_stats')) {
        $link_id = intval($_GET['link_id']);
        global $wpdb;
        $table = $wpdb->prefix . 'dbrd_links';
        $link = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d AND user_id = %d", $link_id, $user_id));

        if ($link) {
            $link_stats = DBRD_Analytics::get_link_stats($link_id, 30);
        }
    }
}

$top_links = DBRD_Analytics::get_top_links($user_id, 5);
?>

<div class="wrap dbrd-admin-wrap">
    <h1><?php esc_html_e('Analytics', 'device-based-redirect-pro'); ?></h1>

    <?php if ($link && $link_stats): ?>
        <!-- Single Link Analytics -->
        <div class="dbrd-analytics-header">
            <h2><?php echo esc_html($link->name); ?></h2>
            <p class="dbrd-link-url">
                <code><?php echo esc_html(DBRD_Router::get_link_url($link->slug)); ?></code>
            </p>
            <a href="<?php echo esc_url(admin_url('admin.php?page=dbrd-analytics')); ?>" class="button">
                <?php esc_html_e('Back to Overview', 'device-based-redirect-pro'); ?>
            </a>
        </div>

        <div class="dbrd-stats-grid">
            <div class="dbrd-stat-card">
                <div class="dbrd-stat-icon">📊</div>
                <div class="dbrd-stat-content">
                    <div class="dbrd-stat-number"><?php echo esc_html(number_format($link_stats['total_clicks'])); ?></div>
                    <div class="dbrd-stat-label"><?php esc_html_e('Total Clicks (30 days)', 'device-based-redirect-pro'); ?></div>
                </div>
            </div>

            <div class="dbrd-stat-card">
                <div class="dbrd-stat-icon">📱</div>
                <div class="dbrd-stat-content">
                    <div class="dbrd-stat-number"><?php echo esc_html(number_format($link_stats['devices']['ios'])); ?></div>
                    <div class="dbrd-stat-label"><?php esc_html_e('iOS Clicks', 'device-based-redirect-pro'); ?></div>
                </div>
            </div>

            <div class="dbrd-stat-card">
                <div class="dbrd-stat-icon">🤖</div>
                <div class="dbrd-stat-content">
                    <div class="dbrd-stat-number"><?php echo esc_html(number_format($link_stats['devices']['android'])); ?></div>
                    <div class="dbrd-stat-label"><?php esc_html_e('Android Clicks', 'device-based-redirect-pro'); ?></div>
                </div>
            </div>

            <div class="dbrd-stat-card">
                <div class="dbrd-stat-icon">💻</div>
                <div class="dbrd-stat-content">
                    <div class="dbrd-stat-number"><?php echo esc_html(number_format($link_stats['devices']['desktop'])); ?></div>
                    <div class="dbrd-stat-label"><?php esc_html_e('Desktop Clicks', 'device-based-redirect-pro'); ?></div>
                </div>
            </div>
        </div>

        <!-- Device Distribution Chart -->
        <div class="dbrd-chart-container">
            <h3><?php esc_html_e('Device Distribution', 'device-based-redirect-pro'); ?></h3>
            <canvas id="dbrd-device-chart" width="400" height="200"></canvas>
        </div>

        <!-- Daily Clicks Chart -->
        <div class="dbrd-chart-container">
            <h3><?php esc_html_e('Clicks Over Time (Last 30 Days)', 'device-based-redirect-pro'); ?></h3>
            <canvas id="dbrd-timeline-chart" width="400" height="200"></canvas>
        </div>

        <?php
        // Pass data to JavaScript via wp_localize_script
        wp_localize_script('dbrd-admin-js', 'dbrdAnalyticsData', array(
            'deviceData' => $link_stats['devices'],
            'dailyData' => $link_stats['daily_clicks']
        ));
        ?>

    <?php else: ?>
        <!-- Overview Analytics -->
        <div class="dbrd-stats-grid">
            <div class="dbrd-stat-card">
                <div class="dbrd-stat-icon">🔗</div>
                <div class="dbrd-stat-content">
                    <div class="dbrd-stat-number"><?php echo esc_html(number_format($overview['total_links'])); ?></div>
                    <div class="dbrd-stat-label"><?php esc_html_e('Total Links', 'device-based-redirect-pro'); ?></div>
                </div>
            </div>

            <div class="dbrd-stat-card">
                <div class="dbrd-stat-icon">✅</div>
                <div class="dbrd-stat-content">
                    <div class="dbrd-stat-number"><?php echo esc_html(number_format($overview['active_links'])); ?></div>
                    <div class="dbrd-stat-label"><?php esc_html_e('Active Links', 'device-based-redirect-pro'); ?></div>
                </div>
            </div>

            <div class="dbrd-stat-card">
                <div class="dbrd-stat-icon">📊</div>
                <div class="dbrd-stat-content">
                    <div class="dbrd-stat-number"><?php echo esc_html(number_format($overview['total_clicks'])); ?></div>
                    <div class="dbrd-stat-label"><?php esc_html_e('All-Time Clicks', 'device-based-redirect-pro'); ?></div>
                </div>
            </div>

            <div class="dbrd-stat-card">
                <div class="dbrd-stat-icon">📅</div>
                <div class="dbrd-stat-content">
                    <div class="dbrd-stat-number"><?php echo esc_html(number_format($overview['monthly_clicks'])); ?></div>
                    <div class="dbrd-stat-label"><?php esc_html_e('This Month', 'device-based-redirect-pro'); ?></div>
                </div>
            </div>

            <div class="dbrd-stat-card">
                <div class="dbrd-stat-icon">📆</div>
                <div class="dbrd-stat-content">
                    <div class="dbrd-stat-number"><?php echo esc_html(number_format($overview['today_clicks'])); ?></div>
                    <div class="dbrd-stat-label"><?php esc_html_e('Today', 'device-based-redirect-pro'); ?></div>
                </div>
            </div>
        </div>

        <?php if (!empty($top_links)): ?>
        <!-- Top Performing Links -->
        <div class="dbrd-top-links">
            <h2><?php esc_html_e('Top Performing Links', 'device-based-redirect-pro'); ?></h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Rank', 'device-based-redirect-pro'); ?></th>
                        <th><?php esc_html_e('Link Name', 'device-based-redirect-pro'); ?></th>
                        <th><?php esc_html_e('Total Clicks', 'device-based-redirect-pro'); ?></th>
                        <th><?php esc_html_e('Actions', 'device-based-redirect-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $rank = 1;
                    foreach ($top_links as $top_link):
                        $stats_url = wp_nonce_url(
                            admin_url('admin.php?page=dbrd-analytics&link_id=' . intval($top_link->id)),
                            'dbrd_view_stats'
                        );
                    ?>
                    <tr>
                        <td>
                            <?php if ($rank <= 3): ?>
                                <span class="dbrd-medal dbrd-medal-<?php echo esc_attr($rank); ?>">
                                    <?php echo $rank === 1 ? '🥇' : ($rank === 2 ? '🥈' : '🥉'); ?>
                                </span>
                            <?php else: ?>
                                <strong><?php echo esc_html($rank); ?></strong>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?php echo esc_html($top_link->name); ?></strong><br>
                            <code><?php echo esc_html(DBRD_Router::get_link_url($top_link->slug)); ?></code>
                        </td>
                        <td>
                            <strong><?php echo esc_html(number_format($top_link->clicks)); ?></strong>
                        </td>
                        <td>
                            <a href="<?php echo esc_url($stats_url); ?>">
                                <?php esc_html_e('View Details', 'device-based-redirect-pro'); ?>
                            </a>
                        </td>
                    </tr>
                    <?php
                    $rank++;
                    endforeach;
                    ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="dbrd-empty-state">
            <div class="dbrd-empty-icon">📊</div>
            <h2><?php esc_html_e('No data yet', 'device-based-redirect-pro'); ?></h2>
            <p><?php esc_html_e('Create some links and share them to see analytics data.', 'device-based-redirect-pro'); ?></p>
            <a href="<?php echo esc_url(admin_url('admin.php?page=dbrd-add-link')); ?>" class="button button-primary">
                <?php esc_html_e('Create a Link', 'device-based-redirect-pro'); ?>
            </a>
        </div>
        <?php endif; ?>

    <?php endif; ?>
</div>
