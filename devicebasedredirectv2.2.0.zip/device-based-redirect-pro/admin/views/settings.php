<?php
/**
 * Settings Admin Page
 */

if (!defined('ABSPATH')) {
    exit;
}

$message = isset($_GET['message']) ? sanitize_text_field(wp_unslash($_GET['message'])) : '';
?>

<div class="wrap dbrd-admin-wrap">
    <h1><?php esc_html_e('Settings', 'device-based-redirect-pro'); ?></h1>

    <?php if ($message === 'data_deleted'): ?>
        <div class="notice notice-success is-dismissible">
            <p><?php esc_html_e('All data has been permanently deleted.', 'device-based-redirect-pro'); ?></p>
        </div>
    <?php endif; ?>

    <!-- FREE Version Section -->
    <div class="dbrd-settings-section">
        <div class="dbrd-license-active">
            <div class="dbrd-license-badge" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                <span class="dbrd-badge-icon">✨</span>
                <span class="dbrd-badge-text"><?php esc_html_e('FREE Version - All Features Unlimited', 'device-based-redirect-pro'); ?></span>
            </div>

            <table class="form-table">
                <tr>
                    <th><?php esc_html_e('Features', 'device-based-redirect-pro'); ?></th>
                    <td>
                        <ul class="dbrd-feature-list">
                            <li><?php esc_html_e('Unlimited Links', 'device-based-redirect-pro'); ?></li>
                            <li><?php esc_html_e('Unlimited Clicks', 'device-based-redirect-pro'); ?></li>
                            <li><?php esc_html_e('Full Analytics & Charts', 'device-based-redirect-pro'); ?></li>
                            <li><?php esc_html_e('100% FREE Forever', 'device-based-redirect-pro'); ?></li>
                        </ul>
                    </td>
                </tr>
            </table>

            <!-- Support Development -->
            <div style="background: #fff3cd; padding: 20px; border-radius: 8px; margin-top: 20px; border-left: 4px solid #ffc107;">
                <h3 style="margin-top: 0;"><?php esc_html_e('Enjoying this plugin?', 'device-based-redirect-pro'); ?></h3>
                <p style="font-size: 16px;"><?php esc_html_e('This plugin is completely free to use. If you find it valuable, consider supporting development:', 'device-based-redirect-pro'); ?></p>
                <a href="https://dailyuseful.tools/donate/" target="_blank" rel="noopener noreferrer" class="button button-primary button-large">
                    <?php esc_html_e('Donate / Buy Me a Coffee', 'device-based-redirect-pro'); ?>
                </a>
            </div>
        </div>

    </div>

    <!-- Plugin Information -->
    <div class="dbrd-settings-section">
        <h2><?php esc_html_e('Plugin Information', 'device-based-redirect-pro'); ?></h2>

        <table class="form-table">
            <tr>
                <th><?php esc_html_e('Version', 'device-based-redirect-pro'); ?></th>
                <td><?php echo esc_html(DBRD_VERSION); ?></td>
            </tr>
            <tr>
                <th><?php esc_html_e('Website', 'device-based-redirect-pro'); ?></th>
                <td>
                    <a href="https://dailyuseful.tools/devicebasedredirect" target="_blank" rel="noopener noreferrer">
                        dailyuseful.tools/devicebasedredirect
                    </a>
                </td>
            </tr>
            <tr>
                <th><?php esc_html_e('Documentation', 'device-based-redirect-pro'); ?></th>
                <td>
                    <a href="https://dailyuseful.tools/devicebasedredirect/docs" target="_blank" rel="noopener noreferrer">
                        <?php esc_html_e('View Documentation', 'device-based-redirect-pro'); ?>
                    </a>
                </td>
            </tr>
            <tr>
                <th><?php esc_html_e('Support', 'device-based-redirect-pro'); ?></th>
                <td>
                    <a href="https://dailyuseful.tools/support" target="_blank" rel="noopener noreferrer">
                        <?php esc_html_e('Get Support', 'device-based-redirect-pro'); ?>
                    </a>
                </td>
            </tr>
        </table>
    </div>

    <!-- Danger Zone -->
    <div class="dbrd-settings-section dbrd-danger-zone">
        <h2><?php esc_html_e('Danger Zone', 'device-based-redirect-pro'); ?></h2>

        <div class="dbrd-danger-content">
            <h3><?php esc_html_e('Delete All Data', 'device-based-redirect-pro'); ?></h3>
            <p><?php esc_html_e('This will permanently delete all your links and analytics data. This action cannot be undone.', 'device-based-redirect-pro'); ?></p>

            <form method="post" id="dbrd-delete-all-form" style="display: inline;">
                <?php wp_nonce_field('dbrd_delete_all_action', 'dbrd_delete_all_nonce'); ?>
                <input type="hidden" name="dbrd_delete_all_data" value="1">
                <button type="button" class="button button-secondary dbrd-danger-button" id="dbrd-delete-all-data">
                    <?php esc_html_e('Delete All Data', 'device-based-redirect-pro'); ?>
                </button>
            </form>

            <p class="description" style="color: #d63638;">
                <?php esc_html_e('Warning: This action is permanent and cannot be undone!', 'device-based-redirect-pro'); ?>
            </p>
        </div>
    </div>
</div>

<?php
// Add delete confirmation script
$delete_script = "
jQuery(document).ready(function($) {
    $('#dbrd-delete-all-data').on('click', function(e) {
        e.preventDefault();

        var firstConfirm = confirm('" . esc_js(__('WARNING: This will permanently delete ALL your links and analytics data. This action CANNOT be undone! Are you absolutely sure?', 'device-based-redirect-pro')) . "');

        if (firstConfirm) {
            var typeDelete = prompt('" . esc_js(__('Type DELETE (in capital letters) to confirm:', 'device-based-redirect-pro')) . "');

            if (typeDelete === 'DELETE') {
                $('#dbrd-delete-all-form').submit();
            } else {
                alert('" . esc_js(__('Deletion cancelled. You did not type DELETE correctly.', 'device-based-redirect-pro')) . "');
            }
        }
    });
});
";
wp_add_inline_script('dbrd-admin-js', $delete_script);
?>
